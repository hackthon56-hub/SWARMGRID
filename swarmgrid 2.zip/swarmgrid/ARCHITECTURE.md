# Architecture

- **Frontend**: React + Three.js + React Three Fiber + TailwindCSS. Uses WebSocket to reflect backend state.
- **Backend**: Node.js + TypeScript + ws. Contains the authoritative simulation engine.
- **Decentralized Engine**: 
  - Local Task Bidding (Agents evaluate utilities independently)
  - A* Pathfinding (Grid-based shortest paths)
  - Collision Avoidance (Next-step reservation tracking)
  - Failure Recovery (Agents drop offline, remaining agents bid for orphaned tasks)
  - Communication Resilience (Agents degrade to local knowledge)
