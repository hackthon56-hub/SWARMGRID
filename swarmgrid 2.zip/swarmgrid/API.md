# REST API

- `GET /api/health`
- `POST /api/simulation/start`
- `POST /api/simulation/pause`

# WebSocket Events

- `STATE_UPDATE`: Complete state broadcast including agents, tasks, obstacles, metrics, events.
- Client -> Server Commands: `START`, `PAUSE`, `RESET`, `ADD_OBSTACLE`, `ADD_TASK`, `FAIL_AGENT`, `DROP_NETWORK`, `RESTORE_NETWORK`.
