import React, { useRef, useEffect } from 'react';
import { Blobatar } from '@blobatar/react';

export type ChatMessage = {
  name: string;
  text: string;
  time: string;
};

export interface GroupChatProps {
  messages: ChatMessage[];
  channel?: string;
  members?: string[];
  typing?: string[];
  blobatar?: boolean;
  className?: string;
}

export function GroupChat({ messages, channel = "SWARM EVENT STREAM", members = [], typing = [], blobatar = true, className = '' }: GroupChatProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  return (
    <div className={`flex flex-col h-full bg-black/40 backdrop-blur border border-white/10 rounded-xl overflow-hidden ${className}`}>
      <div className="p-4 border-b border-white/10 bg-black/50 flex justify-between items-center">
        <h3 className="text-sm font-semibold tracking-wider text-white">{channel}</h3>
        {typing.length > 0 && <span className="text-xs text-orange-400 italic">{typing.join(', ')} typing...</span>}
      </div>
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, i) => (
          <div key={i} className="flex items-start space-x-3">
            {msg.name !== 'SYSTEM' && blobatar ? (
              <div className="flex-shrink-0 w-8 h-8 rounded-full overflow-hidden bg-white/5 border border-white/20">
                <Blobatar name={msg.name} />
              </div>
            ) : (
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-orange-500/20 border border-orange-500/50 flex items-center justify-center">
                <span className="text-[10px] font-bold text-orange-500">{msg.name === 'SYSTEM' ? 'SYS' : msg.name}</span>
              </div>
            )}
            <div className="flex-1 min-w-0">
              <div className="flex items-baseline justify-between space-x-2">
                <span className={`text-xs font-bold ${msg.name === 'SYSTEM' ? 'text-orange-500' : 'text-gray-300'}`}>
                  {msg.name}
                </span>
                <span className="text-[10px] text-gray-500 tabular-nums">
                  {msg.time}
                </span>
              </div>
              <p className={`text-sm mt-0.5 leading-relaxed break-words ${msg.name === 'SYSTEM' ? 'text-gray-400' : 'text-white'}`}>
                {msg.text}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
