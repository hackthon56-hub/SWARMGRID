import React, { useState, useEffect } from 'react';

export function EvaluatorTest({ engineState, onClose }: any) {
  const [phase, setPhase] = useState(0);
  const [results, setResults] = useState<any>({});
  
  useEffect(() => {
    if (!engineState || engineState.status !== 'RUNNING') return;
    
    setResults((prev: any) => {
      const nextResults = { ...prev };
      
      if (engineState.metrics.completed > 0) nextResults.TASK_ALLOCATION = 'PASS';
      if (engineState.metrics.perf?.pathfindingAverage >= 0) nextResults.PATHFINDING = 'PASS';
      if (engineState.metrics.replans > 0) nextResults.REPLANNING = 'PASS';
      if (engineState.events.some((e: any) => e.message.includes('failure'))) nextResults.FAILURE_RECOVERY = 'PASS';
      if (engineState.events.some((e: any) => e.message.includes('restored') || e.message.includes('synchronized'))) nextResults.NETWORK_RECOVERY = 'PASS';
      if (engineState.metrics.perf?.tickAverage >= 0) nextResults.PERFORMANCE = 'PASS';
      
      const hasChanges = Object.keys(nextResults).some(k => nextResults[k] !== prev[k]);
      return hasChanges ? nextResults : prev;
    });
  }, [engineState]);

  useEffect(() => {
    // Run active integration tests
    const runTests = async () => {
      try {
        // Test API Validation
        let apiPass = true;
        const healthRes = await fetch('http://localhost:4000/api/health');
        if (!healthRes.ok) apiPass = false;
        
        // Malformed request
        const badRes = await fetch('http://localhost:4000/api/network/drop', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ invalidField: 123 })
        });
        if (badRes.status !== 400) apiPass = false;
        
        // Test Collision logic via backend sandbox
        const colRes = await fetch('http://localhost:4000/api/evaluator/run-tests', { method: 'POST' });
        const colData = await colRes.json();
        
        setResults((prev: any) => ({
          ...prev,
          API_VALIDATION: apiPass ? 'PASS' : 'FAIL',
          COLLISION: colData.COLLISION || 'FAIL'
        }));
      } catch (e) {
        setResults((prev: any) => ({
          ...prev,
          API_VALIDATION: 'FAIL',
          COLLISION: 'FAIL'
        }));
      }
    };
    runTests();
  }, []);

  return (
    <div className="fixed inset-0 z-50 bg-black/90 flex flex-col items-center justify-center p-8 backdrop-blur-sm">
      <div className="w-full max-w-3xl flex flex-col items-center border border-white/10 rounded-2xl bg-black overflow-hidden p-8">
        <h1 className="text-4xl font-bold tracking-widest text-orange-500 mb-8">EVALUATOR TEST</h1>
        <div className="w-full grid grid-cols-2 gap-6 text-sm">
          {['PATHFINDING', 'TASK ALLOCATION', 'COLLISION', 'REPLANNING', 'FAILURE RECOVERY', 'NETWORK RECOVERY', 'API VALIDATION', 'PERFORMANCE'].map(test => (
            <div key={test} className="flex justify-between items-center border-b border-white/10 pb-2">
              <span className="text-gray-400 font-bold tracking-wider">{test}</span>
              <span className={`font-bold ${results[test.replace(' ', '_')] === 'PASS' ? 'text-green-500' : 'text-yellow-500'}`}>
                {results[test.replace(' ', '_')] || 'PENDING...'}
              </span>
            </div>
          ))}
        </div>
        <button onClick={onClose} className="mt-8 px-6 py-2 bg-orange-600 hover:bg-orange-500 rounded text-sm font-bold tracking-widest">CLOSE</button>
      </div>
    </div>
  );
}
