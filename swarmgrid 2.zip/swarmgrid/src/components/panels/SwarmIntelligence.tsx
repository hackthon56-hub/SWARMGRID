import React from 'react';

export function SwarmIntelligence({ events }: { events: any[] }) {
  const steps = [
    'LOCAL DECISION MAKING',
    'UTILITY-BASED TASK BIDDING',
    'A* PATH PLANNING',
    'RESERVATION-BASED SAFETY',
    'DYNAMIC REPLANNING',
    'FAILURE RECOVERY',
    'COMMUNICATION RESILIENCE'
  ];

  return (
    <div className="flex flex-col h-full bg-black/40 backdrop-blur border border-white/10 rounded-xl overflow-hidden">
      <div className="p-4 border-b border-white/10 bg-black/50">
        <h3 className="text-sm font-semibold tracking-wider text-white">SWARM INTELLIGENCE</h3>
      </div>
      <div className="p-4 flex-1 overflow-y-auto space-y-2">
        {steps.map((step, i) => {
          // simple pseudo matching
          const isActive = events.some(e => 
            (step.includes('BIDDING') && e.message.includes('Bidding')) ||
            (step.includes('PATH') && e.message.includes('path accepted')) ||
            (step.includes('REPLANNING') && e.message.includes('Replanning')) ||
            (step.includes('FAILURE') && e.message.includes('failure')) ||
            (step.includes('COMMUNICATION') && e.message.includes('local mode')) ||
            (step.includes('LOCAL') && events.length > 0) ||
            (step.includes('SAFETY') && events.length > 0)
          );
          return (
            <div key={i} className="flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full ${isActive ? 'bg-orange-500 animate-pulse' : 'bg-gray-700'}`}></div>
              <span className={`text-[10px] font-bold tracking-widest ${isActive ? 'text-orange-400' : 'text-gray-500'}`}>
                {step}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
