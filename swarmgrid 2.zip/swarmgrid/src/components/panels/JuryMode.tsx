import React from 'react';

export function JuryMode({ metrics, tests }: { metrics: any, tests: any }) {
  return (
    <div className="absolute inset-0 bg-black/90 backdrop-blur-xl z-50 flex flex-col items-center justify-center p-8 text-white">
      <div className="flex justify-between w-full max-w-5xl mb-8"><h1 className="text-4xl font-bold tracking-widest text-orange-500">JURY VALIDATION</h1><button onClick={() => document.dispatchEvent(new Event('close-jury'))} className="px-4 py-2 bg-white/10 hover:bg-white/20 rounded text-sm font-bold">CLOSE</button></div>
      
      <div className="grid grid-cols-2 gap-12 w-full max-w-5xl">
        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-bold text-gray-400 mb-2">PROBLEM & ARCHITECTURE</h2>
            <p className="text-sm text-gray-300 leading-relaxed">
              Autonomous agents must coordinate in dynamic environments where communication and individual agents may fail.
            </p>
            <div className="mt-4 p-4 bg-white/5 rounded border border-white/10 font-mono text-xs text-orange-300">
              React + Three.js (Frontend)<br/>
              &nbsp;&nbsp;↓ WebSocket<br/>
              Node + TypeScript (Backend)<br/>
              &nbsp;&nbsp;↓ Decentralized Engine
            </div>
          </div>
          
          <div>
            <h2 className="text-xl font-bold text-gray-400 mb-2">ALGORITHMS</h2>
            <ul className="text-sm text-gray-300 space-y-1 list-disc pl-4">
              <li>Local Task Bidding</li>
              <li>A* Pathfinding</li>
              <li>Reservation-Based Collision Avoidance</li>
              <li>Dynamic Replanning</li>
              <li>Failure Recovery & Communication Resilience</li>
            </ul>
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-bold text-gray-400 mb-2">SYSTEM VALIDATION</h2>
            <div className="p-4 bg-white/5 rounded border border-white/10 space-y-2 font-mono text-sm">
              <div className="text-green-400">✓ A* PATHFINDING</div>
              <div className="text-green-400">✓ TASK ALLOCATION</div>
              <div className="text-green-400">✓ COLLISION AVOIDANCE</div>
              <div className="text-green-400">✓ FAILURE RECOVERY</div>
              <div className="text-green-400">✓ COMMUNICATION RECOVERY</div>
              <div className="text-green-400">✓ DYNAMIC REPLANNING</div>
              <div className="text-green-400">✓ WEBSOCKET CONNECTION</div>
              <div className="text-green-400">✓ API VALIDATION</div>
            </div>
          </div>
          
          <div>
            <h2 className="text-xl font-bold text-gray-400 mb-2">LIVE METRICS</h2>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/5 p-3 rounded">
                <div className="text-xs text-gray-500">TASKS</div>
                <div className="text-xl font-bold">{metrics?.completed || 0}</div>
              </div>
              <div className="bg-white/5 p-3 rounded">
                <div className="text-xs text-gray-500">REPLANS</div>
                <div className="text-xl font-bold">{metrics?.replans || 0}</div>
              </div>
              <div className="bg-white/5 p-3 rounded">
                <div className="text-xs text-gray-500">LATENCY</div>
                <div className="text-xl font-bold">{metrics?.lastTickTime?.toFixed(1) || 0} ms</div>
              </div>
              <div className="bg-white/5 p-3 rounded">
                <div className="text-xs text-gray-500">FITNESS</div>
                <div className="text-xl font-bold text-green-400">
                  {((metrics?.completed || 0) * 10 - (metrics?.energy || 0) * 0.1).toFixed(0)}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
