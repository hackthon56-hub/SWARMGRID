import React from 'react';

export function BottomDock() {
  const items = ['SIMULATION', 'AGENTS', 'MISSIONS', 'SCENARIOS', 'ANALYTICS', 'EVENTS', 'SETTINGS'];
  return (
    <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-2 p-2 bg-black/40 backdrop-blur-md border border-white/10 rounded-full z-50">
      {items.map(item => (
        <button aria-label="Action button" tabIndex={0} key={item} className="px-4 py-2 text-[10px] font-bold tracking-widest text-gray-400 hover:text-white hover:bg-white/10 rounded-full transition-all">
          {item}
        </button>
      ))}
    </div>
  );
}
