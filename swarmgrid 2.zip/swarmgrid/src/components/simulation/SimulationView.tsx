import React, { useRef, useState } from 'react';
import { Canvas, useFrame, ThreeEvent } from '@react-three/fiber';
import { OrbitControls, Grid, Line } from '@react-three/drei';

function AgentMesh({ agent, onClick }: { agent: any, onClick: (a: any) => void }) {
  const ref = useRef<any>(null);
  
  useFrame(() => {
    if (ref.current) {
      // Smooth movement interpolation could go here
      ref.current.position.x = agent.position.x - 10;
      ref.current.position.z = agent.position.y - 10;
    }
  });

  const color = !agent.operationalStatus ? 'gray' : (agent.communicationStatus !== 0 ? 'red' : 'orange');

  return (
    <group ref={ref} onClick={(e) => { e.stopPropagation(); onClick(agent); }}>
      <mesh position={[0, 0.5, 0]}>
        <boxGeometry args={[0.8, 1, 0.8]} />
        <meshStandardMaterial color={color} />
      </mesh>
      {agent.path && agent.path.length > 0 && (
        <Line
          points={[[0, 0.1, 0], ...agent.path.map((p: any) => [p.x - agent.position.x, 0.1, p.y - agent.position.y] as [number, number, number])]}
          color="white"
          lineWidth={2}
          dashed
        />
      )}
    </group>
  );
}

function TaskMesh({ task }: { task: any }) {
  const color = task.status === 3 ? 'green' : (task.status === 1 ? 'yellow' : 'cyan'); // 3 = COMPLETED, 1 = ASSIGNED
  
  if (task.status === 3) return null;

  return (
    <mesh position={[task.position.x - 10, 0.2, task.position.y - 10]}>
      <cylinderGeometry args={[0.4, 0.4, 0.4, 16]} />
      <meshStandardMaterial color={color} />
    </mesh>
  );
}

function ObstacleMesh({ obs }: { obs: any }) {
  return (
    <mesh position={[obs.position.x - 10, 0.5, obs.position.y - 10]}>
      <boxGeometry args={[1, 1, 1]} />
      <meshStandardMaterial color={obs.type === 1 ? 'red' : 'purple'} />
    </mesh>
  );
}

export function SimulationView({ engine, onSelectAgent, onAddObstacle, onAddTask }: { engine: any, onSelectAgent: (a: any | null) => void, onAddObstacle: (p: {x: number, y: number}) => void, onAddTask: (p: {x: number, y: number}) => void }) {
  const [clickMode, setClickMode] = useState<'SELECT' | 'OBSTACLE' | 'TASK'>('SELECT');

  const handlePointerDown = (e: ThreeEvent<PointerEvent>) => {
    if (clickMode === 'SELECT') {
      onSelectAgent(null);
    } else {
      const x = Math.round(e.point.x + 10);
      const y = Math.round(e.point.z + 10);
      if (clickMode === 'OBSTACLE') onAddObstacle({ x, y });
      if (clickMode === 'TASK') onAddTask({ x, y });
    }
  };

  return (
    <div className="w-full h-full bg-black relative">
      <div className="absolute top-24 left-4 z-10 flex gap-2">
         <button aria-label="Action button" tabIndex={0} onClick={() => setClickMode('SELECT')} className={`px-3 py-1 text-xs font-bold rounded ${clickMode === 'SELECT' ? 'bg-orange-500 text-white' : 'bg-white/10 text-gray-400 hover:bg-white/20'}`}>SELECT</button>
         <button aria-label="Action button" tabIndex={0} onClick={() => setClickMode('OBSTACLE')} className={`px-3 py-1 text-xs font-bold rounded ${clickMode === 'OBSTACLE' ? 'bg-orange-500 text-white' : 'bg-white/10 text-gray-400 hover:bg-white/20'}`}>PLACE OBSTACLE</button>
         <button aria-label="Action button" tabIndex={0} onClick={() => setClickMode('TASK')} className={`px-3 py-1 text-xs font-bold rounded ${clickMode === 'TASK' ? 'bg-orange-500 text-white' : 'bg-white/10 text-gray-400 hover:bg-white/20'}`}>PLACE TASK</button>
      </div>
      <Canvas camera={{ position: [0, 15, 15], fov: 50 }}>
        <ambientLight intensity={0.5} />
        <directionalLight position={[10, 10, 5]} intensity={1} />
        
        <mesh position={[0, -0.05, 0]} rotation={[-Math.PI / 2, 0, 0]} onPointerDown={handlePointerDown}>
          <planeGeometry args={[20, 20]} />
          <meshBasicMaterial visible={false} />
        </mesh>
        
        <Grid args={[20, 20]} sectionColor={'#444'} cellColor={'#222'} position={[0, -0.01, 0]} />
        
        {engine.agents.map((a: any) => (
          <AgentMesh key={a.id} agent={a} onClick={onSelectAgent} />
        ))}
        
        {engine.tasks.map((t: any) => (
          <TaskMesh key={t.id} task={t} />
        ))}
        
        {engine.obstacles.map((o: any) => (
          <ObstacleMesh key={o.id} obs={o} />
        ))}
        
        <OrbitControls makeDefault />
      </Canvas>
    </div>
  );
}
