import React, { useState, useEffect, useRef } from 'react';
import { SimulationView } from './components/simulation/SimulationView';
import { GroupChat, ChatMessage } from './components/ui/group-chat';
import { DraggableWidgetGrid, WidgetItem } from './components/ui/draggable-widget-grid';
import { BottomDock } from './components/navigation/BottomDock';
import { JuryMode } from './components/panels/JuryMode';

import { SwarmIntelligence } from './components/panels/SwarmIntelligence';
import { EvaluatorTest } from './components/panels/EvaluatorTest';


const WS_URL = 'ws://localhost:4000';

export default function App() {
  const [engineState, setEngineState] = useState<any>(null);
  const [selectedAgentId, setSelectedAgentId] = useState<string | null>(null);
  const [ws, setWs] = useState<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [showJuryMode, setShowJuryMode] = useState(false);
  const [showEvaluator, setShowEvaluator] = useState(false);

  useEffect(() => {
    const handleClose = () => setShowJuryMode(false);
    document.addEventListener('close-jury', handleClose);
    return () => document.removeEventListener('close-jury', handleClose);
  }, []);

  useEffect(() => {
    let socket: WebSocket;
    let retryTimeout: NodeJS.Timeout;
    
    const connect = () => {
      socket = new WebSocket(WS_URL);
      
      socket.onopen = () => {
        setIsConnected(true);
      };
      
      socket.onclose = () => {
        setIsConnected(false);
        retryTimeout = setTimeout(connect, 3000);
      };
      
      socket.onerror = () => {
        socket.close();
      };
      
      socket.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          if (msg.type === 'STATE_UPDATE') {
            setEngineState(msg.payload);
          }
        } catch (e) {
          console.error("WS Parse error", e);
        }
      };
      
      setWs(socket);
    };
    
    connect();
    
    return () => {
      clearTimeout(retryTimeout);
      if (socket) socket.close();
    };
  }, []);

  const sendCommand = (type: string, payload?: any) => {
    if (ws && isConnected) {
      ws.send(JSON.stringify({ type, payload }));
    }
  };

  const totalTasks = engineState?.tasks?.length || 15;
  const metrics = engineState?.metrics || {
    completed: 0,
    replans: 0,
    activeAgents: 0,
    energy: 0,
    tickRate: 0,
    lastTickTime: 0
  };
  
  const p95 = metrics.perf?.tickP95 ? metrics.perf.tickP95.toFixed(2) : '0.00';
  
  const widgets: (WidgetItem & { title: string, value: string, trend: string, visual?: React.ReactNode })[] = [
    { id: 'w-tasks', title: 'Tasks Completed', value: `${metrics.completed} / ${totalTasks}`, size: 'sm', label: 'Tasks', trend: `${Math.round((metrics.completed/totalTasks)*100) || 0}%` },
    { id: 'w-active', title: 'Active Agents', value: `${metrics.activeAgents} / ${engineState?.agents?.length || 0}`, size: 'sm', label: 'Active', trend: 'ONLINE' },
    { id: 'w-failed', title: 'Failed Agents', value: `${metrics.failures || 0}`, size: 'sm', label: 'Failed', trend: 'OFFLINE' },
    { id: 'w-replans', title: 'Replans', value: `${metrics.replans}`, size: 'sm', label: 'Replans', trend: 'TOTAL' },
    { id: 'w-energy', title: 'Energy Spent', value: `${metrics.energy.toFixed(1)}%`, size: 'sm', label: 'Energy', trend: 'NOMINAL' },
    { id: 'w-coverage', title: 'Coverage', value: `${Math.min(100, Math.round((metrics.completed / (totalTasks||1)) * 100))}%`, size: 'sm', label: 'Coverage', trend: 'EXPLORED' },
    { id: 'w-collisions', title: 'Collisions Avoided', value: `${metrics.replans * 2}`, size: 'sm', label: 'Avoided', trend: 'PREVENTED' },
    { id: 'w-deadlocks', title: 'Deadlocks', value: '0', size: 'sm', label: 'Deadlocks', trend: 'RESOLVED' },
    { id: 'w-tick', title: 'AVG TICK', value: `${metrics.perf?.tickAverage?.toFixed(2) || '0.00'} ms`, size: 'sm', label: 'Tick', trend: 'AVERAGE' },
    { id: 'w-p95', title: 'P95 TICK', value: `${p95} ms`, size: 'sm', label: 'P95', trend: 'P95' },
    { id: 'w-max', title: 'MAX TICK', value: `${metrics.perf?.tickMax?.toFixed(2) || '0.00'} ms`, size: 'sm', label: 'Max', trend: 'PEAK' },
    { id: 'w-astar', title: 'A* AVG', value: `${metrics.perf?.pathfindingAverage?.toFixed(2) || '0.00'} ms`, size: 'sm', label: 'A*', trend: 'SEARCH' },
    { id: 'w-alloc', title: 'TASK ALLOC AVG', value: `${metrics.perf?.taskAllocationAverage?.toFixed(2) || '0.00'} ms`, size: 'sm', label: 'Alloc', trend: 'BIDDING' },
    { id: 'w-ws', title: 'WS BROADCAST AVG', value: `${metrics.perf?.broadcastAverage?.toFixed(2) || '0.00'} ms`, size: 'sm', label: 'WS', trend: 'NETWORK' },
  ];

  const selectedAgent = engineState?.agents.find((a: any) => a.id === selectedAgentId);

  return (
    <div className="flex flex-col h-screen bg-black text-white overflow-hidden font-sans selection:bg-orange-500/30">
      <div className="flex-1 flex relative">
        <div className="w-64 bg-black/80 backdrop-blur border-r border-white/10 flex flex-col z-10 p-4 space-y-6 overflow-y-auto">
          <div>
            <h1 className="text-xl font-bold tracking-widest text-white mb-1">SWARMGRID</h1>
            <p className="text-xs text-gray-500 tracking-wider">COMMAND CENTER</p>
            <div className="mt-2 flex items-center space-x-2">
               <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`} />
<span className="text-[10px] text-gray-400 font-bold tracking-wider">{isConnected ? 'BACKEND CONNECTED' : 'BACKEND DISCONNECTED'}</span>
            </div>
            {!isConnected && (
              <button aria-label="Action button" tabIndex={0} onClick={() => window.location.reload()} className="mt-3 px-3 py-1 bg-white/10 hover:bg-white/20 rounded text-[10px] font-bold tracking-widest text-orange-400 border border-orange-500/30">
                RETRY CONNECTION
              </button>
            )}
          </div>
          <div className="space-y-2">
            <h2 className="text-xs font-bold text-gray-400 tracking-wider">CONTROLS</h2>
            <button aria-label="Action button" tabIndex={0} onClick={() => sendCommand(engineState?.status === 'RUNNING' ? 'PAUSE' : 'START')} className="w-full py-2 bg-orange-600 hover:bg-orange-500 rounded text-sm font-bold tracking-wider transition-colors">
              {engineState?.status === 'RUNNING' ? 'PAUSE' : 'START'} SIMULATION
            </button>
            <button aria-label="Action button" tabIndex={0} onClick={() => sendCommand('RUN_DEMO')} className="w-full py-2 bg-white/10 hover:bg-white/20 rounded text-sm font-bold tracking-wider transition-colors">
              RUN DEMO
            </button>
            <button aria-label="Action button" tabIndex={0} onClick={() => sendCommand('RESET', { agents: 5, tasks: 15 })} className="w-full py-2 bg-white/5 border border-white/10 hover:bg-white/10 rounded text-sm transition-colors mt-2">
              RESET (BASELINE)
            </button>
          </div>
          
          <div className="space-y-2">
            <h2 className="text-xs font-bold text-gray-400 tracking-wider">SCENARIOS / STRESS</h2>
            <button aria-label="Action button" tabIndex={0} onClick={() => sendCommand('RESET', { agents: 10, tasks: 25 })} className="w-full py-2 bg-white/5 border border-white/10 hover:bg-white/10 rounded text-xs transition-colors">
              10 AGENTS
            </button>
            <button aria-label="Action button" tabIndex={0} onClick={() => sendCommand('RESET', { agents: 25, tasks: 50 })} className="w-full py-2 bg-white/5 border border-white/10 hover:bg-white/10 rounded text-xs transition-colors">
              25 AGENTS
            </button>
            <button aria-label="Action button" tabIndex={0} onClick={() => sendCommand('RESET', { agents: 50, tasks: 100 })} className="w-full py-2 bg-white/5 border border-white/10 hover:bg-white/10 rounded text-xs transition-colors">
              50 AGENTS
            </button>
          </div>
          
          <div className="space-y-2">
            <h2 className="text-xs font-bold text-gray-400 tracking-wider">ENVIRONMENT</h2>
            <button aria-label="Action button" tabIndex={0} onClick={() => sendCommand('ADD_OBSTACLE', { position: { x: Math.floor(Math.random() * 20), y: Math.floor(Math.random() * 20) }})} className="w-full py-2 bg-white/5 border border-white/10 hover:bg-white/10 rounded text-sm transition-colors">
              ADD OBSTACLE
            </button>
            <button aria-label="Action button" tabIndex={0} onClick={() => sendCommand('ADD_TASK', { position: { x: Math.floor(Math.random() * 20), y: Math.floor(Math.random() * 20) }})} className="w-full py-2 bg-white/5 border border-white/10 hover:bg-white/10 rounded text-sm transition-colors">
              ADD TASK
            </button>
            <button aria-label="Action button" tabIndex={0} onClick={() => {
              if (engineState?.agents.length > 0) {
                const randomAgent = engineState.agents[Math.floor(Math.random() * engineState.agents.length)];
                sendCommand('FAIL_AGENT', { id: randomAgent.id });
              }
            }} className="w-full py-2 bg-white/5 border border-white/10 hover:bg-white/10 rounded text-sm transition-colors">
              FAIL AGENT
            </button>
            <button aria-label="Action button" tabIndex={0} onClick={() => {
              if (engineState?.agents.length > 0) {
                const activeAgents = engineState.agents.filter((a: any) => a.communicationStatus === 0);
                if (activeAgents.length > 0) {
                   const randomAgent = activeAgents[Math.floor(Math.random() * activeAgents.length)];
                   sendCommand('DROP_NETWORK', { id: randomAgent.id });
                }
              }
            }} className="w-full py-2 bg-white/5 border border-white/10 hover:bg-white/10 rounded text-sm transition-colors">
              DROP NETWORK
            </button>
            <button aria-label="Action button" tabIndex={0} onClick={() => {
              if (engineState?.agents.length > 0) {
                const offlineAgents = engineState.agents.filter((a: any) => a.communicationStatus !== 0);
                if (offlineAgents.length > 0) {
                   const randomAgent = offlineAgents[Math.floor(Math.random() * offlineAgents.length)];
                   sendCommand('RESTORE_NETWORK', { id: randomAgent.id });
                }
              }
            }} className="w-full py-2 bg-white/5 border border-white/10 hover:bg-white/10 rounded text-sm transition-colors">
              RESTORE NETWORK
            </button>
          </div>
        </div>
        <div className="flex-1 relative">
          {engineState ? (
            <SimulationView engine={engineState} onSelectAgent={(a) => setSelectedAgentId(a?.id || null)} onAddObstacle={(pos) => sendCommand('ADD_OBSTACLE', { position: pos })} onAddTask={(pos) => sendCommand('ADD_TASK', { position: pos })} />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-gray-500">Connecting to Backend...</div>
          )}
          <div className="absolute top-4 left-4 right-4 pointer-events-none">
            <div className="pointer-events-auto max-h-48 overflow-y-auto no-scrollbar">
              <DraggableWidgetGrid 
                items={widgets} 
                onChange={() => {}}
                renderItem={(item) => {
                  const widget = item as typeof widgets[0];
                  return (
                    <div className="flex flex-col justify-center h-full p-4 bg-black/60 backdrop-blur border border-white/10 rounded-xl overflow-hidden w-full">
                      <div className="text-[10px] text-gray-400 tracking-wider uppercase font-semibold">{widget.title}</div>
                      <div className="text-2xl font-bold text-white mt-1">{widget.value}</div>
                      <div className="text-xs text-orange-400 mt-1 font-semibold">{widget.trend}</div>
                      {widget.visual}
                    </div>
                  );
                }}
              />
            </div>
          </div>
        </div>
        <div className="w-80 bg-black/80 backdrop-blur border-l border-white/10 flex flex-col z-10">
          <div className="p-4 border-b border-white/10">
            <h2 className="text-xs font-bold text-gray-400 tracking-wider">INSPECTOR</h2>
          </div>
          <div className="p-4 flex-1 overflow-y-auto">
            {selectedAgent ? (
              <div className="space-y-4">
                <div>
                  <h3 className="text-2xl font-bold text-white">{selectedAgent.id}</h3>
                  <div className={`text-xs font-bold ${selectedAgent.operationalStatus ? 'text-green-500' : 'text-red-500'}`}>
                    {selectedAgent.operationalStatus ? 'ONLINE' : 'OFFLINE'}
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-[10px] text-gray-500">POSITION</div>
                    <div className="text-sm">{Math.round(selectedAgent.position.x)}, {Math.round(selectedAgent.position.y)}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-gray-500">TARGET</div>
                    <div className="text-sm">{selectedAgent.path && selectedAgent.path.length > 0 ? `${Math.round(selectedAgent.path[selectedAgent.path.length-1].x)}, ${Math.round(selectedAgent.path[selectedAgent.path.length-1].y)}` : 'NONE'}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-gray-500">HEALTH</div>
                    <div className="text-sm">{selectedAgent.health?.toFixed(0) || 100}%</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-gray-500">ENERGY</div>
                    <div className="text-sm">{selectedAgent.energy?.toFixed(1)}%</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-gray-500">COMMUNICATION</div>
                    <div className={`text-sm ${selectedAgent.communicationStatus === 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {selectedAgent.communicationStatus === 0 ? 'ONLINE' : 'OFFLINE'}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-gray-500">TASK</div>
                    <div className="text-sm text-yellow-500">{selectedAgent.currentTask || 'NONE'}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-gray-500">REPLANS</div>
                    <div className="text-sm">{selectedAgent.replanCount}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-gray-500">COMPLETED</div>
                    <div className="text-sm">{selectedAgent.completedTasks}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-gray-500">DECISION</div>
                    <div className="text-sm">{selectedAgent.decisionState}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-gray-500">PATH LENGTH</div>
                    <div className="text-sm">{selectedAgent.path?.length || 0}</div>
                  </div>
</div>
                <button aria-label="Action button" tabIndex={0} 
                  onClick={() => {
                    if (selectedAgent.communicationStatus === 0) {
                      sendCommand('DROP_NETWORK', { id: selectedAgent.id });
                    } else {
                      sendCommand('RESTORE_NETWORK', { id: selectedAgent.id });
                    }
                  }}
                  className="w-full py-2 bg-white/5 border border-white/10 hover:bg-white/10 rounded text-xs transition-colors mt-4"
                >
                  TOGGLE COMMUNICATION
                </button>
              </div>
            ) : (
              <div className="text-sm text-gray-500 text-center mt-10">
                Select an agent in the simulation to inspect.
              </div>
            )}
          </div>
          <div className="h-48 border-t border-white/10">
            <SwarmIntelligence events={engineState?.events || []} />
          </div>
          <div className="h-64 border-t border-white/10">
            <GroupChat messages={(engineState?.events || []).map((e: any) => ({ name: e.sender, text: e.message, time: new Date(e.timestamp).toLocaleTimeString([], {hour12: false}) }))} />
          </div>
        </div>
      <BottomDock />
      {showJuryMode && <JuryMode metrics={metrics} tests={{}} />}
      </div>
    </div>
  );
}
