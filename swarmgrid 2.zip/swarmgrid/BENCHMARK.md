# SwarmGrid Benchmark Results

| Agents | Tasks | Avg Tick (ms) | P95 Tick (ms) | Max Tick (ms) | Tasks Completed | Replans |
|---|---|---|---|---|---|---|
| 10 | 20 | 0.001 | 0.001 | 0.001 | 16 | 3037 |
| 25 | 50 | 0.002 | 0.002 | 0.002 | 38 | 9914 |
| 50 | 100 | 0.005 | 0.005 | 0.025 | 65 | 33713 |
| 100 | 200 | 0.030 | 0.036 | 0.053 | 92 | 88569 |
