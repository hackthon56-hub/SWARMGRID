const { SwarmEngine } = require('./dist/swarm/SwarmEngine.js');
const fs = require('fs');
const configs = [
  { agents: 10, tasks: 20 },
  { agents: 25, tasks: 50 },
  { agents: 50, tasks: 100 },
  { agents: 100, tasks: 200 }
];

let md = '# SwarmGrid Benchmark Results\n\n| Agents | Tasks | Avg Tick (ms) | P95 Tick (ms) | Max Tick (ms) | Tasks Completed | Replans |\n|---|---|---|---|---|---|---|\n';

configs.forEach(conf => {
  const engine = new SwarmEngine(20, 20);
  engine.initScenario(conf.agents, conf.tasks);
  
  for(let i=0; i<1000; i++) {
    engine.tick();
    if (i === 100 && engine.agents[1]) engine.failAgent(engine.agents[1].id);
    if (i === 200 && engine.agents[2]) engine.dropCommunication(engine.agents[2].id);
    if (i === 300 && engine.agents[2]) engine.restoreCommunication(engine.agents[2].id);
  }
  
  const perf = engine.getPerformanceMetrics();
  const metrics = engine.getMetrics();
  md += `| ${conf.agents} | ${conf.tasks} | ${perf.tickAverage.toFixed(3)} | ${perf.tickP95.toFixed(3)} | ${perf.tickMax.toFixed(3)} | ${metrics.completed} | ${metrics.replans} |\n`;
});

fs.writeFileSync('../BENCHMARK.md', md);
console.log("Benchmark complete.");
