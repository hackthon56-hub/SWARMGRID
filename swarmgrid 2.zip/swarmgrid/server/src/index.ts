import { World } from './swarm/World';
import { Agent } from './swarm/Agent';
import express from 'express';
import cors from 'cors';
import { WebSocketServer, WebSocket } from 'ws';
import http from 'http';
import { SwarmEngine } from './swarm/SwarmEngine';

import { z } from 'zod';

const MessageSchema = z.object({
  type: z.enum(['START', 'PAUSE', 'RESET', 'RUN_DEMO', 'ADD_OBSTACLE', 'ADD_TASK', 'FAIL_AGENT', 'DROP_NETWORK', 'RESTORE_NETWORK']),
  payload: z.any().optional()
});

const PointSchema = z.object({
  x: z.number().min(0).max(100),
  y: z.number().min(0).max(100)
});

import { AgentStatus } from './swarm/Agent';

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

app.use(cors());
app.use(express.json());

const engine = new SwarmEngine(20, 20);
engine.initScenario(5, 15);

let isRunning = false;
let tickInterval: NodeJS.Timeout | null = null;
const TICK_RATE = 200; // 5 Hz

function startSimulation() {
  if (isRunning) return;
  isRunning = true;
  tickInterval = setInterval(() => {
    const start = performance.now();
    engine.tick();
    const end = performance.now();
    broadcastState(end - start);
  }, TICK_RATE);
}

function pauseSimulation() {
  isRunning = false;
  if (tickInterval) clearInterval(tickInterval);
  broadcastState(0);
}

function broadcastState(tickTimeMs: number) {
  const start = performance.now();
  const perf = engine.getPerformanceMetrics();
  let avgPathfind = 0;
  let pathCount = 0;
  engine.agents.forEach(a => {
    if (a.lastPathfindMs > 0) {
       avgPathfind += a.lastPathfindMs;
       pathCount++;
       a.lastPathfindMs = 0;
    }
  });
  if (pathCount > 0) {
     engine.pathfindingDurations.push(avgPathfind / pathCount);
     if (engine.pathfindingDurations.length > 100) engine.pathfindingDurations.shift();
  }

  const state = {
    type: 'STATE_UPDATE',
    payload: {
      status: isRunning ? 'RUNNING' : 'PAUSED',
      agents: engine.agents.map(a => ({
        id: a.id,
        position: a.position,
        energy: a.energy,
        health: a.health,
        currentTask: a.currentTask?.id || null,
        path: a.path,
        communicationStatus: a.communicationStatus,
        operationalStatus: a.operationalStatus,
        replanCount: a.replanCount,
        completedTasks: a.completedTasks,
        decisionState: !a.operationalStatus ? 'FAILED' :
                       a.communicationStatus !== 0 ? 'OFFLINE' :
                       a.path.length > 0 ? 'MOVING' :
                       a.currentTask ? 'WORKING' : 'IDLE'
      })),
      tasks: engine.tasks,
      obstacles: Array.from(engine.world.obstacles.values()),
      events: engine.events,
      metrics: {
        ...engine.getMetrics(),
        tickRate: 1000 / TICK_RATE,
        lastTickTime: perf.tickAverage, 
        perf: perf
      }
    }
  };

  const data = JSON.stringify(state);
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(data);
    }
  });
  
  engine.broadcastDurations.push(performance.now() - start);
  if (engine.broadcastDurations.length > 100) engine.broadcastDurations.shift();
}

wss.on('connection', (ws) => {
  ws.send(JSON.stringify({ type: 'CONNECTED' }));
  broadcastState(0);
  
  ws.on('message', (message) => {
    try {
      const raw = JSON.parse(message.toString());
      const parsed = MessageSchema.safeParse(raw);
      if (!parsed.success) {
         ws.send(JSON.stringify({ type: 'ERROR', payload: 'Invalid message format' }));
         return;
      }
      
      const { type, payload } = parsed.data;
      
      switch (type) {
        case 'RUN_DEMO':
          engine.runDemo(broadcastState);
          startSimulation();
          break;
        case 'START':
          startSimulation();
          break;
        case 'PAUSE':
          pauseSimulation();
          break;
        case 'RESET':
          pauseSimulation();
          engine.initScenario(payload?.agents || 5, payload?.tasks || 10);
          broadcastState(0);
          break;
        case 'ADD_OBSTACLE':
          if (payload && PointSchema.safeParse(payload).success) {
             engine.addDynamicObstacle(payload);
          }
          break;
        case 'ADD_TASK':
          if (payload && PointSchema.safeParse(payload).success) {
             engine.addTask('T' + Date.now(), payload);
          }
          break;
        case 'FAIL_AGENT':
          if (payload?.id) engine.failAgent(payload.id);
          break;
        case 'DROP_NETWORK':
          if (payload?.id) engine.dropCommunication(payload.id);
          break;
        case 'RESTORE_NETWORK':
          if (payload?.id) engine.restoreCommunication(payload.id);
          break;
      }
      broadcastState(0);
    } catch (e) {
      // Ignored
    }
  });
});

function handleCommand(msg: any) {
  switch (msg.type) {
    case 'RUN_DEMO':
      engine.runDemo(broadcastState);
      startSimulation();
      break;
    case 'START':
      startSimulation();
      break;
    case 'PAUSE':
      pauseSimulation();
      break;
    case 'RESET':
      engine.initScenario(msg.payload?.agents || 5, msg.payload?.tasks || 15);
      broadcastState(0);
      break;
    case 'ADD_OBSTACLE':
      engine.addDynamicObstacle(msg.payload.position);
      broadcastState(0);
      break;
    case 'FAIL_AGENT':
      engine.failAgent(msg.payload.id);
      broadcastState(0);
      break;
    case 'DROP_NETWORK':
      engine.dropCommunication(msg.payload.id);
      broadcastState(0);
      break;
    case 'RESTORE_NETWORK':
      engine.restoreCommunication(msg.payload.id);
      broadcastState(0);
      break;
    case 'ADD_TASK':
      engine.addTask(`T_MANUAL_${Date.now()}`, msg.payload.position);
      broadcastState(0);
      break;
  }
}

// REST API
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', running: isRunning });
});

app.post('/api/simulation/start', (req, res) => {
  startSimulation();
  res.json({ status: 'started' });
});

app.post('/api/simulation/pause', (req, res) => {
  pauseSimulation();
  res.json({ status: 'paused' });

app.get('/api/simulation', (req, res) => {
  res.json({ status: isRunning ? 'RUNNING' : 'PAUSED', tickRate: TICK_RATE });
});

app.get('/api/agents', (req, res) => {
  res.json(engine.agents);
});

app.get('/api/tasks', (req, res) => {
  res.json(engine.tasks);
});

app.get('/api/environment', (req, res) => {
  res.json({ width: engine.world.width, height: engine.world.height, obstacles: Array.from(engine.world.obstacles.values()) });
});

app.get('/api/metrics', (req, res) => {
  res.json({ ...engine.getMetrics(), perf: engine.getPerformanceMetrics() });
});

app.get('/api/events', (req, res) => {
  res.json(engine.events);
});

app.post('/api/simulation/reset', (req, res) => {
  pauseSimulation();
  engine.initScenario(req.body.agents || 5, req.body.tasks || 10);
  broadcastState(0);
  res.json({ status: 'reset' });
});

app.post('/api/agents/:id/fail', (req, res) => {
  engine.failAgent(req.params.id);
  broadcastState(0);
  res.json({ status: 'failed', id: req.params.id });
});

app.post('/api/network/drop', (req, res) => {
  engine.dropCommunication(req.body.id);
  broadcastState(0);
  res.json({ status: 'offline', id: req.body.id });
});

app.post('/api/network/restore', (req, res) => {
  engine.restoreCommunication(req.body.id);
  broadcastState(0);
  res.json({ status: 'online', id: req.body.id });

app.post('/api/evaluator/run-tests', (req, res) => {
  try {
    // 1. Collision deterministic test
    
    
    const world = new World(10, 10);
    const a1 = new Agent('EVAL_A1', {x: 1, y: 5}, world);
    const a2 = new Agent('EVAL_A2', {x: 3, y: 5}, world);
    
    // Force them into same cell (2,5)
    a1.path = [{x: 2, y: 5}, {x: 3, y: 5}];
    a2.path = [{x: 2, y: 5}, {x: 1, y: 5}];
    
    // Tick
    a1.update(world, [a1, a2], () => {});
    a2.update(world, [a1, a2], () => {});
    
    const collisionPass = (a1.position.x !== a2.position.x) || (a1.position.y !== a2.position.y);
    
    res.json({ status: 'ok', COLLISION: collisionPass ? 'PASS' : 'FAIL' });
  } catch (e) {
    res.status(500).json({ status: 'error', error: e instanceof Error ? e.message : "Unknown error" });
  }
});
});
});

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
