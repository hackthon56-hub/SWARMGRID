import { Point2D } from './World';

export enum TaskStatus {
  AVAILABLE,
  ASSIGNED,
  IN_PROGRESS,
  COMPLETED,
  BLOCKED,
  UNASSIGNED
}

export interface Task {
  id: string;
  position: Point2D;
  priority: number;
  status: TaskStatus;
  assignedAgent: string | null;
  createdAt: number;
  deadline?: number;
}
