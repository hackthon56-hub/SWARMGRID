import { Point2D, World } from './World';
import { Task, TaskStatus } from './Task';
import { PathPlanner } from './PathPlanner';

export enum AgentStatus {
  ONLINE,
  DEGRADED,
  OFFLINE
}

export class Agent {
  public id: string;
  public position: Point2D;
  public velocity: Point2D = { x: 0, y: 0 };
  public energy: number = 100;
  public health: number = 100;
  public priority: number = 1;
  
  public currentTask: Task | null = null;
  public taskHistory: string[] = [];
  public path: Point2D[] = [];
  public localMap: World;
  
  public communicationStatus: AgentStatus = AgentStatus.ONLINE;
  public operationalStatus: boolean = true;
  
  public replanCount: number = 0;
  public completedTasks: number = 0;
  public distanceTraveled: number = 0;
  public lastPathfindMs: number = 0;

  constructor(id: string, startPos: Point2D, world: World) {
    this.id = id;
    this.position = { ...startPos };
    this.localMap = new World(world.width, world.height);
  }

  evaluateTask(task: Task): number {
    if (this.communicationStatus === AgentStatus.OFFLINE) return -1;
    if (!this.operationalStatus) return -1;
    if (task.status !== TaskStatus.AVAILABLE && task.status !== TaskStatus.UNASSIGNED) return -1;
    
    const dist = PathPlanner.heuristic(this.position, task.position);
    // Utility function: priority / distance. Less distance = higher utility.
    // Factor in energy if low.
    if (this.energy < 10) return -1;
    
    return (task.priority * 10) / (dist + 1);
  }

  assignTask(task: Task, world: World) {
    this.currentTask = task;
    this.planPath(task.position, world);
  }

planPath(goal: Point2D, world: World, avoidAgents: Point2D[] = []) {
    const start = performance.now();
    this.path = PathPlanner.findPath(world, this.position, goal, avoidAgents);
    if (this.path.length === 0) {
       // Cannot reach
    } else {
       this.path.shift(); // remove current position
    }
    // we can't easily push to engine from here, but we can store it on agent
    this.lastPathfindMs = performance.now() - start;
  }
  update(world: World, otherAgents: Agent[], onEvent: (msg: string, isSys?: boolean) => void) {
    if (!this.operationalStatus) return;
    
    // Check if current path is blocked by dynamic obstacles
    if (this.path.length > 0) {
      const nextStep = this.path[0];
      if (world.isBlocked(nextStep)) {
        this.replanCount++;
        onEvent(`Obstacle detected ahead. Path invalidated.`, false);
        onEvent(`${this.id} path invalidated.`, true);
        if (this.currentTask) {
           this.planPath(this.currentTask.position, world);
           onEvent(`Replanning route.`, false);
           onEvent(`New path accepted.`, true);
        }
      } else {
        // Simple collision avoidance
        const conflict = otherAgents.find(a => a.id !== this.id && Math.round(a.position.x) === Math.round(nextStep.x) && Math.round(a.position.y) === Math.round(nextStep.y));
        if (conflict) {
          // Wait
          this.replanCount++; // Treat collision wait as a minor replan / resolution event for metrics tracking
          return;
        }

        // Move

        // Move
        this.position = nextStep;
        this.path.shift();
        this.energy -= 0.1;
        this.distanceTraveled += 1;
        
        if (this.currentTask && this.path.length === 0) {
          if (Math.round(this.position.x) === Math.round(this.currentTask.position.x) && Math.round(this.position.y) === Math.round(this.currentTask.position.y)) {
             this.completedTasks++;
             this.currentTask.status = TaskStatus.COMPLETED;
             this.taskHistory.push(this.currentTask.id);
             this.currentTask = null;
          }
        }
      }
    }
  }
}
