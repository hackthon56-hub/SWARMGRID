import { Point2D, World } from './World';

export class PathPlanner {
  static heuristic(a: Point2D, b: Point2D) {
    return Math.abs(a.x - b.x) + Math.abs(a.y - b.y);
  }

  static findPath(world: World, start: Point2D, goal: Point2D, avoidPositions: Point2D[] = []): Point2D[] {
    const openSet = new Set<string>();
    const closedSet = new Set<string>();
    const cameFrom = new Map<string, Point2D>();
    
    const gScore = new Map<string, number>();
    const fScore = new Map<string, number>();

    const toKey = (p: Point2D) => `${Math.round(p.x)},${Math.round(p.y)}`;
    const startKey = toKey(start);

    openSet.add(startKey);
    gScore.set(startKey, 0);
    fScore.set(startKey, this.heuristic(start, goal));

    const getLowestF = () => {
      let lowest = Infinity;
      let bestKey = '';
      for (const key of openSet) {
        const score = fScore.get(key) ?? Infinity;
        if (score < lowest) {
          lowest = score;
          bestKey = key;
        }
      }
      return bestKey;
    };

    while (openSet.size > 0) {
      const currentKey = getLowestF();
      if (!currentKey) break;

      const [cx, cy] = currentKey.split(',').map(Number);
      const current = { x: cx, y: cy };

      if (cx === Math.round(goal.x) && cy === Math.round(goal.y)) {
        const path = [];
        let curr = currentKey;
        while (cameFrom.has(curr)) {
          const p = cameFrom.get(curr)!;
          path.push(p);
          curr = toKey(p);
        }
        path.reverse();
        path.push(goal);
        return path;
      }

      openSet.delete(currentKey);
      closedSet.add(currentKey);

      const neighbors = [
        { x: cx + 1, y: cy },
        { x: cx - 1, y: cy },
        { x: cx, y: cy + 1 },
        { x: cx, y: cy - 1 },
      ];

      for (const n of neighbors) {
        if (world.isBlocked(n)) continue;
        const avoid = avoidPositions.some(ap => Math.round(ap.x) === n.x && Math.round(ap.y) === n.y);
        if (avoid && (n.x !== Math.round(goal.x) || n.y !== Math.round(goal.y))) continue;

        const nKey = toKey(n);
        if (closedSet.has(nKey)) continue;

        const tentativeG = (gScore.get(currentKey) ?? Infinity) + 1;

        if (!openSet.has(nKey)) {
          openSet.add(nKey);
        } else if (tentativeG >= (gScore.get(nKey) ?? Infinity)) {
          continue;
        }

        cameFrom.set(nKey, current);
        gScore.set(nKey, tentativeG);
        fScore.set(nKey, tentativeG + this.heuristic(n, goal));
      }
    }
    
    return []; // No path found
  }
}
