export type ChatEvent = {
  id: string;
  sender: string;
  message: string;
  timestamp: Date;
  isSystem?: boolean;
};
