import { World, Obstacle, ObstacleType } from './World';
import { Agent, AgentStatus } from './Agent';
import { Task, TaskStatus } from './Task';
import { ChatEvent } from './Events';

export class SwarmEngine {
  public world: World;
  public agents: Agent[] = [];
  public tasks: Task[] = [];
  public events: ChatEvent[] = [];
  public tickRate: number = 200;

  public demoTickCount = -1;
  
  runDemo(broadcastState: (tickTimeMs: number) => void) {
    this.initScenario(5, 10);
    this.demoTickCount = 0;
    this.addEvent('SYSTEM', 'DEMO SEQUENCE INITIATED', true);
  }

  
  public collisionAttempts = 0;
  public conflictsResolved = 0;
  public deadlocks = 0;

  constructor(width: number, height: number) {
    this.world = new World(width, height);
  }

  addEvent(sender: string, message: string, isSystem: boolean = false) {
    this.events = [...this.events, {
      id: Math.random().toString(36).substr(2, 9),
      sender,
      message,
      timestamp: new Date(),
      isSystem
    }].slice(-50);
  }

  initScenario(agentCount: number, taskCount: number) {
    this.agents = [];
    this.tasks = [];
    this.events = [];
    
    for (let i = 0; i < agentCount; i++) {
      this.agents.push(new Agent(`A${i + 1}`, { x: Math.floor(Math.random() * this.world.width), y: Math.floor(Math.random() * this.world.height) }, this.world));
    }
    
    for (let i = 0; i < taskCount; i++) {
      this.addTask(`T${i + 1}`, { x: Math.floor(Math.random() * this.world.width), y: Math.floor(Math.random() * this.world.height) });
    }
    
    this.addEvent('SYSTEM', `Scenario initialized with ${agentCount} agents and ${taskCount} tasks.`, true);
  }

  addTask(id: string, position: {x: number, y: number}) {
    this.tasks.push({
      id,
      position,
      priority: Math.random() > 0.8 ? 2 : 1,
      status: TaskStatus.AVAILABLE,
      assignedAgent: null,
      createdAt: Date.now()
    });
  }

  
public tickDurations: number[] = [];
  public pathfindingDurations: number[] = [];
  public taskAllocationDurations: number[] = [];
  public collisionDurations: number[] = [];
  public broadcastDurations: number[] = [];
  
  public getPerformanceMetrics() {
    const avg = (arr: number[]) => arr.length ? arr.reduce((a: number, b: number) => a + b, 0) / arr.length : 0;
    const max = (arr: number[]) => arr.length ? Math.max(...arr) : 0;
    
    const p95Calc = (arr: number[]) => {
      if (arr.length === 0) return 0;
      const sorted = [...arr].sort((a, b) => a - b);
      const index = Math.ceil(sorted.length * 0.95) - 1;
      return sorted[Math.max(0, index)];
    };
    
    return {
      tickAverage: avg(this.tickDurations),
      tickMax: max(this.tickDurations),
      tickP95: p95Calc(this.tickDurations),
      pathfindingAverage: avg(this.pathfindingDurations),
      taskAllocationAverage: avg(this.taskAllocationDurations),
      collisionAverage: avg(this.collisionDurations),
      broadcastAverage: avg(this.broadcastDurations),
    };
  }

  tick() {
    const startTick = performance.now();
    
    if (this.demoTickCount >= 0) {
      this.demoTickCount++;
      if (this.demoTickCount === 20) {
         let target = { x: this.agents[0].position.x + 1, y: this.agents[0].position.y };
         if (this.agents[0].path && this.agents[0].path.length > 0) {
             target = this.agents[0].path[0];
         }
         this.addDynamicObstacle(target);
      } else if (this.demoTickCount === 40) {
         this.failAgent(this.agents[1].id);
      } else if (this.demoTickCount === 60) {
         this.dropCommunication(this.agents[2].id);
      } else if (this.demoTickCount === 80) {
         this.restoreCommunication(this.agents[2].id);
      } else if (this.demoTickCount === 100) {
         this.addEvent('SYSTEM', 'DEMO SEQUENCE COMPLETE', true);
         this.demoTickCount = -1;
      }
    }
    
    const availableTasks = this.tasks.filter(t => t.status === TaskStatus.AVAILABLE || t.status === TaskStatus.UNASSIGNED);
    
    const startTaskAllocation = performance.now();
    for (const task of availableTasks) {
      let bestAgent: Agent | null = null;
      let bestUtility = -1;
      
      for (const agent of this.agents) {
        if (agent.currentTask === null && agent.operationalStatus && agent.communicationStatus !== AgentStatus.OFFLINE) {
          const utility = agent.evaluateTask(task);
          if (utility > bestUtility) {
            bestUtility = utility;
            bestAgent = agent;
          }
        }
      }
      
      if (bestAgent) {
        this.addEvent(bestAgent.id, `Bidding for ${task.id}.`);
        bestAgent.assignTask(task, this.world);
        task.status = TaskStatus.ASSIGNED;
        task.assignedAgent = bestAgent.id;
        this.addEvent('SYSTEM', `${bestAgent.id} assigned ${task.id}.`, true);
      }
    }
    this.taskAllocationDurations.push(performance.now() - startTaskAllocation);
    if (this.taskAllocationDurations.length > 100) this.taskAllocationDurations.shift();

    const startCollision = performance.now();
    for (const agent of this.agents) {
      const agentPathStart = performance.now();
      // inside update it does pathfinding if needed, we'll measure coarse collision/update
      agent.update(this.world, this.agents, (msg, isSys) => this.addEvent(agent.id, msg, isSys));
      // pathfinding is internal to agent update
      
      if (!agent.operationalStatus && agent.currentTask) {
        const t = agent.currentTask;
        t.status = TaskStatus.UNASSIGNED;
        t.assignedAgent = null;
        agent.currentTask = null;
        this.addEvent('SYSTEM', `${t.id} released due to agent failure.`, true);
      }
    }
    this.collisionDurations.push(performance.now() - startCollision);
    if (this.collisionDurations.length > 100) this.collisionDurations.shift();
    
    this.tickDurations.push(performance.now() - startTick);
    if (this.tickDurations.length > 100) this.tickDurations.shift();
  }
  failAgent(agentId: string) {
    const a = this.agents.find(a => a.id === agentId);
    if (a && a.operationalStatus) {
      a.operationalStatus = false;
      this.addEvent('SYSTEM', `${agentId} failed.`, true);
    }
  }
  
  dropCommunication(agentId: string) {
    const a = this.agents.find(a => a.id === agentId);
    if (a) {
      a.communicationStatus = AgentStatus.OFFLINE;
      this.addEvent(a.id, `Communication lost.`);
      this.addEvent('SYSTEM', `${a.id} operating in local mode.`, true);
    }
  }
  
  restoreCommunication(agentId: string) {
    const a = this.agents.find(a => a.id === agentId);
    if (a) {
      a.communicationStatus = AgentStatus.ONLINE;
      this.addEvent(a.id, `Network restored.`);
      this.addEvent('SYSTEM', `${a.id} state synchronized.`, true);
    }
  }
  
  addDynamicObstacle(position: {x: number, y: number}) {
    const id = `OBS_${Date.now()}`;
    this.world.addObstacle({ id, position, type: ObstacleType.DYNAMIC });
    this.addEvent('SYSTEM', `Dynamic obstacle added at ${position.x}, ${position.y}.`, true);
  }
  
  getMetrics() {
    let completed = 0;
    let replans = 0;
    let distance = 0;
    let energy = 0;
    let failures = 0;
    
    this.agents.forEach(a => {
      completed += a.completedTasks;
      replans += a.replanCount;
      distance += a.distanceTraveled;
      energy += (100 - a.energy);
      if (!a.operationalStatus) failures++;
    });
    
    return {
      completed,
      replans,
      distance,
      energy,
      failures,
      activeAgents: this.agents.length - failures
    };
  }
}
