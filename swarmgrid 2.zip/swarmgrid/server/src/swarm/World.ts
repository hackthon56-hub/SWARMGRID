export type Point2D = { x: number; y: number };

export enum ObstacleType {
  STATIC,
  DYNAMIC,
  DANGER_ZONE
}

export interface Obstacle {
  id: string;
  position: Point2D;
  type: ObstacleType;
}

export class World {
  public width: number;
  public height: number;
  public obstacles: Map<string, Obstacle>;

  constructor(width: number, height: number) {
    this.width = width;
    this.height = height;
    this.obstacles = new Map();
  }

  isOutOfBounds(p: Point2D): boolean {
    return p.x < 0 || p.x >= this.width || p.y < 0 || p.y >= this.height;
  }

  isBlocked(p: Point2D): boolean {
    if (this.isOutOfBounds(p)) return true;
    for (const obs of this.obstacles.values()) {
      if (Math.round(obs.position.x) === Math.round(p.x) && Math.round(obs.position.y) === Math.round(p.y)) {
        return true;
      }
    }
    return false;
  }

  addObstacle(obs: Obstacle) {
    this.obstacles.set(obs.id, obs);
  }

  removeObstacle(id: string) {
    this.obstacles.delete(id);
  }
}
