import { describe, it, expect, beforeEach } from 'vitest';
import { SwarmEngine } from '../src/swarm/SwarmEngine';
import { Agent, AgentStatus } from '../src/swarm/Agent';
import { World } from '../src/swarm/World';
import { TaskStatus } from '../src/swarm/Task';
import { PathPlanner } from '../src/swarm/PathPlanner';

describe('SwarmGrid Core Test Suite', () => {
  let engine: SwarmEngine;

  beforeEach(() => {
    engine = new SwarmEngine(20, 20);
  });

  describe('Simulation Lifecycle', () => {
    it('should initialize scenario correctly', () => {
      engine.initScenario(5, 10);
      expect(engine.agents.length).toBe(5);
      expect(engine.tasks.length).toBe(10);
      const metrics = engine.getMetrics();
      expect(metrics.activeAgents).toBe(5);
      expect(metrics.completed).toBe(0);
    });

    it('should calculate metrics correctly', () => {
      engine.initScenario(1, 0);
      engine.tasks.push({ id: 'T0', position: { x: 0, y: 0 }, priority: 1, status: TaskStatus.COMPLETED, assignedAgent: 'A0' });
      expect(engine.getMetrics().completed).toBe(1);
    });
  });

  describe('Agent Behavior & Communication', () => {
    it('should handle agent failure and task reassignment', () => {
      engine.initScenario(2, 1);
      engine.tick(); 
      const agent0 = engine.agents[0];
      const task = engine.tasks[0];
      expect(agent0.currentTask).toBe(task);
      expect(task.status).toBe(TaskStatus.ASSIGNED);
      
      engine.failAgent(agent0.id);
      engine.tick();
      expect(agent0.operationalStatus).toBe(false);
      expect(agent0.currentTask).toBeNull();
      
      engine.tick(); // Reassign
      const agent1 = engine.agents[1];
      expect(agent1.currentTask).toBe(task);
    });

    it('should handle communication drop and recovery', () => {
      engine.initScenario(1, 1);
      const a = engine.agents[0];
      
      engine.dropCommunication(a.id);
      expect(a.communicationStatus).toBe(AgentStatus.OFFLINE);
      
      engine.restoreCommunication(a.id);
      expect(a.communicationStatus).toBe(AgentStatus.ONLINE);
    });
  });

  describe('Pathfinding & A*', () => {
    it('should plan path around obstacles', () => {
      engine.initScenario(1, 1);
      engine.agents[0].position = { x: 0, y: 0 };
      engine.tasks[0].position = { x: 2, y: 0 };
      
      engine.world.obstacles.set('1,0', { x: 1, y: 0 });
      engine.agents[0].planPath(engine.tasks[0].position, engine.world);
      
      // Should route around (0,1 or something)
      expect(engine.agents[0].path.length).toBeGreaterThan(0);
      expect(engine.agents[0].path[0].x).not.toBe(1);
    });

    it('should dynamically replan when obstacle appears', () => {
      engine.initScenario(1, 1);
      engine.agents[0].position = { x: 0, y: 0 };
      engine.tasks[0].position = { x: 5, y: 0 };
      
      engine.tick(); // plan
      expect(engine.agents[0].path.length).toBeGreaterThan(0);
      
      // Place obstacle in front
      const nextStep = engine.agents[0].path[0];
      engine.addDynamicObstacle(nextStep);
      
      const prevReplan = engine.agents[0].replanCount;
      engine.tick(); // detect obstacle and replan
      expect(engine.agents[0].replanCount).toBe(prevReplan + 1);
    });

    it('should return empty path if unreachable target', () => {
      const world = new World(3, 3);
      world.obstacles.set('1,0', {x: 1, y: 0});
      world.obstacles.set('0,1', {x: 0, y: 1});
      world.obstacles.set('1,1', {x: 1, y: 1});
      // (0,0) is walled off
      const path = PathPlanner.findPath(world, {x:0, y:0}, {x:2, y:2});
      expect(path.length).toBe(0);
    });
  });

  describe('Task Allocation', () => {
    it('should allocate tasks via bidding (utility)', () => {
      engine.initScenario(2, 2);
      // Put A0 right next to T1 and A1 next to T0
      engine.agents[0].position = { x: 0, y: 0 };
      engine.tasks[1].position = { x: 1, y: 0 };
      engine.agents[1].position = { x: 5, y: 5 };
      engine.tasks[0].position = { x: 6, y: 5 };
      
      engine.tick();
      expect(engine.agents[0].currentTask?.id).toBe(engine.tasks[1].id);
      expect(engine.agents[1].currentTask?.id).toBe(engine.tasks[0].id);
    });
  });

  describe('Collision Avoidance', () => {
    it('should prevent swap conflicts / same-cell collisions', () => {
      // Create a narrow corridor scenario
      const world = new World(5, 5);
      const a1 = new Agent('A1', {x:1, y:0}, world);
      const a2 = new Agent('A2', {x:3, y:0}, world);
      
      // a1 wants to go right, a2 wants to go left, they meet at x:2
      a1.path = [{x:2, y:0}];
      a2.path = [{x:2, y:0}];
      
      const onEvent = () => {};
      a1.update(world, [a1, a2], onEvent);
      a2.update(world, [a1, a2], onEvent);
      
      // They should not both be at 2,0
      expect(a1.position.x === 2 && a2.position.x === 2).toBe(false);
    });
  });
});
