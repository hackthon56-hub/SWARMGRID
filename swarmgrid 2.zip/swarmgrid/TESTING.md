# Testing

Tests are written using Vitest in the backend `server/tests/` directory.

Run tests:
`npm run test`

## Strategy
- Agent Creation & Movement
- Task Bidding & Assignment
- A* Pathfinding around static walls
- Dynamic replanning when path is blocked
- Communication loss simulation
