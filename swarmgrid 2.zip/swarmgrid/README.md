# SWARMGRID

A decentralized multi-agent coordination engine where autonomous agents collaboratively execute tasks, avoid collisions, adapt to changing environments, and recover from agent or communication failures without relying on a single centralized controller.

## Setup

1. `npm install` (root)
2. `cd server && npm install`
3. `cd .. && npm run dev`

Runs the backend at `localhost:4000` and the frontend at `localhost:5173`.
